import { useState, useRef } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import { Rnd } from "react-rnd";
import { v4 as uuidv4 } from "uuid";
import "react-pdf/dist/esm/Page/AnnotationLayer.css";
import "react-pdf/dist/esm/Page/TextLayer.css";
import "./App.css";
import SignaturePad from "./SignaturePad";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.mjs`;

function App() {
  const [file, setFile] = useState(null);
  const [numPages, setNumPages] = useState(null);
  const [pageNumber, setPageNumber] = useState(1);
  const [fields, setFields] = useState([]);
  const containerRef = useRef(null);
  const [showSignaturePad, setShowSignaturePad] = useState(false);
  const [activeFieldId, setActiveFieldId] = useState(null);
  const [signatures, setSignatures] = useState({});

  // Handle PDF file upload
  const handleFileUpload = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
  };

  // PDF document load success handler
  const onDocumentLoadSuccess = ({ numPages }) => {
    setNumPages(numPages);
  };


  // Drag and Drop handlers
  const handleDragStart = (e, type) => {
    e.dataTransfer.setData("text/plain", type);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const type = e.dataTransfer.getData("text/plain");
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) ;
    const y = (e.clientY - rect.top) ;

    setFields([
      ...fields,
      {
        id: uuidv4(),
        type,
        page: pageNumber,
        x,
        y,
        width: 100,
        height: 40,
      },
    ]);
    console.log("Field added:", { type, x, y, page: pageNumber, width: 100, height: 40 });
  };

  // Field manipulation handlers
  const updateFieldPosition = (id, x, y) => {
    setFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id
          ? {
              ...field,
              x,
              y,
            }
          : field
      )
    );
  };

  const updateFieldSize = (id, width, height) => {
    setFields((fields) =>
      fields.map((field) =>
        field.id === id ? { ...field, width, height } : field
      )
    );
    console.log("fields", fields);
  };

  const handleSignatureClick = (fieldId) => {
    if (!signatures[fieldId]) {
      setActiveFieldId(fieldId);
      setShowSignaturePad(true);
    }
  };

  const handleSignatureSave = (signatureBase64) => {
    setSignatures({
      ...signatures,
      [activeFieldId]: signatureBase64,
    });
    console.log("Signature saved:", signatureBase64);
  };

  const handleFieldValueChange = (id, value) => {
    setFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id ? { ...field, value } : field
      )
    );
  };

  const handleLogFields = () => {
    const formattedFields = fields.map((field) => {
      const { id, type, x, y, width, height } = field;
      const value = type === "signature"
        ? signatures[id] || ""
        : field.value || "";
      return {
        id,
        type,
        position: { x, y, width, height },
        value,
      };
    });
    console.log("Fields:", formattedFields);
  };

  const handleGeneratePDF = async () => {
    if (!file) return;
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const existingPdfBytes = new Uint8Array(e.target.result);
        const pdfDoc = await PDFDocument.load(existingPdfBytes);
        const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);

        for (const field of fields) {
          const { id, page, x, y, width, height, type, value } = field;
          if (page <= pdfDoc.getPageCount()) {
            const pdfPage = pdfDoc.getPages()[page - 1];
            const adjustedY = pdfPage.getHeight() - (y + height);
            let fontSize = Math.min(height * 0.7, width / 8);
            if (type === "signature" && signatures[id]) {
              const base64Data = signatures[id].split(",")[1];
              const signatureBytes = Uint8Array.from(
                atob(base64Data),
                (char) => char.charCodeAt(0)
              );
              const signatureImage = await pdfDoc.embedPng(signatureBytes);
              pdfPage.drawImage(signatureImage, {
                x,
                y: adjustedY,
                width,
                height,
              });
            } else {
              const textValue = value || "";
              pdfPage.drawText(textValue, {
                x,
                y: adjustedY,
                font: helveticaFont,
                size: fontSize,
                color: rgb(0, 0, 0),
              });
            }
          }
        }

        const pdfBytes = await pdfDoc.save();
        const blob = new Blob([pdfBytes], { type: "application/pdf" });
        const url = URL.createObjectURL(blob);
        window.open(url);
      };
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error("Error generating PDF:", error);
    }
  };

  return (
    <div className="app">
      {/* Sidebar */}
      <div className="sidebar">
        <div
          className="field-type"
          draggable
          onDragStart={(e) => handleDragStart(e, "text")}
        >
          Text Field
        </div>
        <div
          className="field-type"
          draggable
          onDragStart={(e) => handleDragStart(e, "date")}
        >
          Date Field
        </div>
        <div
          className="field-type"
          draggable
          onDragStart={(e) => handleDragStart(e, "signature")}
        >
           Signature
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <input
          type="file"
          onChange={handleFileUpload}
          accept="application/pdf"
        />

        {file && (
          <div className="pdf-container">
            <Document file={file} onLoadSuccess={onDocumentLoadSuccess}>
              <div
                className="page-container"
                ref={containerRef}
                style={{ position: "relative" }}
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
              >
                <Page
                  pageNumber={pageNumber}
                />

                {fields
                  .filter((field) => field.page === pageNumber)
                  .map((field) => (
                    <Rnd
                      key={field.id}
                      position={{
                        x: field.x ,
                        y: field.y,
                      }}
                      size={{
                        width: field.width ,
                        height: field.height,
                      }}
                      onDragStop={(e, d) => {
                        e.stopPropagation();
                        updateFieldPosition(field.id, d.x , d.y );
                      }}
                      onResizeStop={(e, direction, ref, delta, position) => {
                        const newWidth = ref.offsetWidth ;
                        const newHeight = ref.offsetHeight ;
                        console.log("Field resized:", { width: newWidth, height: newHeight });

                        updateFieldSize(field.id, newWidth, newHeight);
                        updateFieldPosition(
                          field.id,
                          position.x ,
                          position.y 
                        );
                      }}
                      bounds="parent"
                      minWidth={20 }
                      minHeight={20 }
                      enableResizing={{
                        top: true,
                        right: true,
                        bottom: true,
                        left: true,
                        topLeft: true,
                        topRight: true,
                        bottomLeft: true,
                        bottomRight: true,
                      }}
                      style={{ zIndex: 10 }}
                    >
                      <div className="field">
                        {field.type === "text" && (
                          <input
                            type="text"
                            placeholder="Text"
                            onChange={(e) => handleFieldValueChange(field.id, e.target.value)}
                          />
                        )}
                        {field.type === "date" && (
                          <input
                            type="date"
                            onChange={(e) => handleFieldValueChange(field.id, e.target.value)}
                          />
                        )}
                        {field.type === "signature" && (
                          <div 
                            className="signature-box"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSignatureClick(field.id);
                            }}
                            style={{ cursor: signatures[field.id] ? 'default' : 'pointer' }}
                          >
                            {signatures[field.id] ? (
                              <img 
                                src={signatures[field.id]} 
                                alt="signature" 
                                style={{ width: '100%', height: '100%', pointerEvents: 'none' }}
                              />
                            ) : (
                              <span>Click to sign</span>
                            )}
                          </div>
                        )}
                      </div>
                    </Rnd>
                  ))}
              </div>
            </Document>

            {/* Add signature pad modal */}
            {showSignaturePad && (
              <div className="signature-modal">
                <SignaturePad
                  onSave={handleSignatureSave}
                  onClose={() => setShowSignaturePad(false)}
                />
              </div>
            )}

            {/* Pagination */}
            {numPages > 1 && (
              <div className="pagination">
                <button
                  onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
                  disabled={pageNumber <= 1}
                >
                  Previous
                </button>
                <span>
                  Page {pageNumber} of {numPages}
                </span>
                <button
                  onClick={() =>
                    setPageNumber(Math.min(numPages, pageNumber + 1))
                  }
                  disabled={pageNumber >= numPages}
                >
                  Next
                </button>
              </div>
            )}
          </div>
        )}
        <button onClick={handleLogFields}>Log Fields</button>
        <button onClick={handleGeneratePDF}>Generate PDF</button>
      </div>
    </div>
  );
}

export default App;